import {Address} from './address';

export class User{
  id: number = undefined;
  email: string = undefined;
  address: Address;
}
